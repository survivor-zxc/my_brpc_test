cmake .
make -j4
